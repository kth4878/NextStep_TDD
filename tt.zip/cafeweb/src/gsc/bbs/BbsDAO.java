package gsc.bbs;

public class BbsDAO {

}
