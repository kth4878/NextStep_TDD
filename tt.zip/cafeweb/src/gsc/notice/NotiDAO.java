package gsc.notice;

public class NotiDAO {

}
